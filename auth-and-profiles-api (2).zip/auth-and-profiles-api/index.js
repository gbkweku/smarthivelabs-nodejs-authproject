require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const bodyParser = require('body-parser');

// Routes
const authRoutes = require('./routes/authRoutes');
const profileRoutes = require('./routes/profileRoutes');

const app = express();
app.use(helmet());
app.use(cors());
app.use(bodyParser.json());

// Health check route
app.get('/', (req, res) => res.json({ ok: true, note: 'Supabase-backed auth & profiles' }));

// Set the correct API path prefixes to match /api/auth and /api/profiles
app.use('/api/auth', authRoutes);
app.use('/api/profiles', profileRoutes); // Corrected to use plural 'profiles'

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on :${PORT}`));
