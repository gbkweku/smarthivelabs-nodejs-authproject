const { supabase } = require('../utils/supabaseClient')

async function supabaseAuth(req, res, next) {
    const auth = req.headers.authorization;
    
    // 1. Check for Bearer token format
    if (!auth || !auth.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Missing Authorization header or invalid format' });
    }
    
    // 2. Extract token
    const token = auth.split(' ')[1];
    
    try {
        // 3. Verify token with Supabase
        const { data, error } = await supabase.auth.getUser(token);
        
        if (error || !data || !data.user) {
            console.error('Supabase token verification failed:', error?.message || 'No user data');
            return res.status(401).json({ error: 'Invalid or expired token' });
        }
        
        // 4. Attach user object
        req.user = data.user;
        return next();
        
    } catch (err) {
        console.error('Authentication process error:', err);
        return res.status(401).json({ error: 'Authentication failed' });
    }
}

module.exports = supabaseAuth;
