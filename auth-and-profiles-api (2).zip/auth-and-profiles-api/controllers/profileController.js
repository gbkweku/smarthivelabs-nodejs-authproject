const { supabase } = require('../utils/supabaseClient')

// POST /api/profiles - Create Profile
const createProfile = async (req, res) => {
    // Get the authenticated user's ID
    const user_id = req.user.id
    const { username, full_name } = req.body

    if (!username) {
        return res.status(400).json({ message: 'Username is required' })
    }

    try {
        const { data, error } = await supabase
            .from('profiles')
            .insert([
                { id: user_id, username, full_name: full_name || null }
            ])
            .select() // Return the created record

        if (error) {
            // Handle unique constraint violation (username already exists)
            if (error.code === '23505') {
                 return res.status(409).json({ message: 'Username already taken' })
            }
            return res.status(400).json({ message: error.message })
        }

        return res.status(201).json({ 
            message: 'Profile created successfully', 
            profile: data[0] 
        })
    } catch (error) {
        console.error('Create profile error:', error)
        return res.status(500).json({ message: 'Server failed to process request' })
    }
}


// GET /api/profiles/me - Get My Profile
const getProfile = async (req, res) => {
    const user_id = req.user.id

    try {
        const { data, error } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', user_id)
            .single() // Expect only one result

        if (error && error.code !== 'PGRST116') { // PGRST116 means No Rows Found
            return res.status(400).json({ message: error.message })
        }

        if (!data) {
            return res.status(404).json({ message: 'Profile not found' })
        }

        return res.status(200).json({ profile: data })

    } catch (error) {
        console.error('Get profile error:', error)
        return res.status(500).json({ message: 'Server failed to process request' })
    }
}


// PUT /api/profiles/me - Update My Profile
const updateProfile = async (req, res) => {
    const user_id = req.user.id
    const { username, full_name } = req.body

    try {
        const { data, error } = await supabase
            .from('profiles')
            .update({ username, full_name })
            .eq('id', user_id)
            .select()

        if (error) {
            if (error.code === '23505') { 
                 return res.status(409).json({ message: 'Username already taken' })
            }
            return res.status(400).json({ message: error.message })
        }

        return res.status(200).json({ 
            message: 'Profile updated successfully', 
            profile: data[0] 
        })

    } catch (error) {
        console.error('Update profile error:', error)
        return res.status(500).json({ message: 'Server failed to process request' })
    }
}

// EXPORT ALL DEFINED FUNCTIONS
module.exports = { createProfile, getProfile, updateProfile }
