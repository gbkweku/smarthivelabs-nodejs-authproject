const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

// Helper to get user from JWT
const getUser = async (req) => {
    const token = req.headers.authorization.split(' ')[1];
    const { data: { user } } = await supabase.auth.getUser(token);
    return user;
};

const createProfile = async (req, res) => {
  const user = await getUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const { name, email, skills, bio, location } = req.body;
  const { data, error } = await supabase
    .from('profiles')
    .insert([{ id: user.id, name, email, skills, bio, location }])
    .select();

  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json(data[0]);
};

const getProfile = async (req, res) => {
  const user = await getUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const { data, error } = await supabase.from('profiles').select('*').eq('id', user.id).single();

  if (error) return res.status(404).json({ error: 'Profile not found' });
  res.status(200).json(data);
};

const updateProfile = async (req, res) => {
  const user = await getUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const { name, skills, bio, location } = req.body;
  const { data, error } = await supabase
    .from('profiles')
    .update({ name, skills, bio, location })
    .eq('id', user.id)
    .select();

  if (error) return res.status(400).json({ error: error.message });
  res.status(200).json(data[0]);
};

const deleteProfile = async (req, res) => {
  const user = await getUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const { error } = await supabase.from('profiles').delete().eq('id', user.id);

  if (error) return res.status(400).json({ error: error.message });
  res.status(200).json({ message: 'Profile deleted successfully' });
};

module.exports = { createProfile, getProfile, updateProfile, deleteProfile };