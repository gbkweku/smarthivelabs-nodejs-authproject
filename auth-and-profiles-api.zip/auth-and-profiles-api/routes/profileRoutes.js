const express = require('express');
const router = express.Router();
const profileController = require('../controllers/profileController');

// All routes here are protected and operate on the authenticated user's profile.
router.post('/', profileController.createProfile);
router.get('/', profileController.getProfile);
router.put('/', profileController.updateProfile);
router.delete('/', profileController.deleteProfile);

module.exports = router;