 const supabase = require('../utils/supabaseClient');

// POST /auth/signup
exports.signup = async (req, res) => {
  try {
    const { email, password } = req.body;
    const { data, error } = await supabase.auth.signUp({
      email,
      password
    });

    if (error) {
      console.error('signup error', error);
      return res.status(400).json({ error: error.message });
    }

    return res.status(200).json({
      user: data.user,
      message: 'signup initiated'
    });
  } catch (err) {
    console.error('signup error', err);
    res.status(500).json({ error: 'server error' });
  }
};


// POST /auth/login
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) return res.status(400).json({ error: error.message });
    res.json({ session: data.session });
  } catch (err) {
    console.error('login error', err);
    res.status(500).json({ error: 'server error' });
  }
};
