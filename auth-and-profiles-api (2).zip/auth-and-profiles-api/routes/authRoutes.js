const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// signup & login endpoints
router.post('/signup', authController.signup);
router.post('/login', authController.login);

module.exports = router;   // ✅ export the router itself
