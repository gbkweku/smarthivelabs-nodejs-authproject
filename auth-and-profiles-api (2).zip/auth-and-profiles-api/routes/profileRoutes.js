const express = require('express')
const router = express.Router()
const supabaseAuth = require('../middleware/supabaseAuth') // Import the function directly
const profileController = require('../controllers/profileController') 

// Use the imported function directly
// POST /api/profiles - Create Profile
router.post('/', supabaseAuth, profileController.createProfile)

// GET /api/profiles/me - Get My Profile
router.get('/me', supabaseAuth, profileController.getProfile)

// PUT /api/profiles/me - Update My Profile
router.put('/me', supabaseAuth, profileController.updateProfile)

module.exports = router
